# My Project Name

This is my WAD Assignment. It includes HTML, CSS, JS, and more.
